package zuulframework;



public class Game 
{
    private Parser parser;
    private Room currentRoom;
    public Game(){
        createRooms();
        parser = new Parser();
    }

    private void createRooms(){
        Room etvhq, corridor, pub, lab, tvstation;
      
        etvhq = new Room("at the ETV headquarter.");
        corridor = new Room("in the corridor at the ETV headquarter.");
        tvstation = new Room("at the TV station. Congratulations!");
        
        etvhq.setExit("east", corridor);

        corridor.setExit("west", etvhq);

        currentRoom = etvhq;
    }

    public void play(){            
        printWelcome();
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing.  Good bye.");
    }

    private void printWelcome(){
        System.out.println();
        System.out.println("COCOA enters the room.");
        System.out.println("COCOA: Noc, how was your weekend?");
        System.out.println("NOC: Good NIGGA! And you?");
        System.out.println("COCOA: Oh, it was just UN-BE-LIEVABLE! Thanks for asking!");
        System.out.println("COCOA whispers to Noc: Meet me in the conference room at about 4 PM. I wanna talk to you and Chase.");
        System.out.println("COCOA: Zeus, my man.");
        System.out.println("COCOA: Hey Checkerface, those white and blacks are looking extra defined today.");
        System.out.println("CHECKERFACE: Uh-, uh- you're looking pretty sexy yourself, boss!");
        System.out.println("COCOA: Skittles, go fuck yourself.");
        System.out.println("SKITTLES: Right back atcha, boss!");
        System.out.println("COCOA: Where's-uh, where's Chase?");
        System.out.println("SKITTLES: He's upstairs playing a game, as usual.");
        System.out.println("COCOA: Alright.");
        System.out.println("COCOA goes upstairs.");
        System.out.println("COCOA: Chase, my man, your show is killing it out there!");
        System.out.println("CHASE: Thanks, K.O.");
        System.out.println("COCOA: No, thank YOU. You're doing 80 times as much as Skittles ever did.");
        System.out.println("COCOA: I basically just wanted to tell you that you and Noc are my two main men,");
        System.out.println("COCOA: and I want to have a meeting with the both of you later. Conference room at 4 P.M.");
        System.out.println("COCOA: I'll see you then.");
        System.out.println("COCOA goes back downstairs, and meets up with the rest of the crew.");
        System.out.println("");
        System.out.println("Oh, and if you need any help, type '" + CommandWord.HELP + "' and we'll send Skittles right to ya!");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        CommandWord commandWord = command.getCommandWord();

        if(commandWord == CommandWord.UNKNOWN) {
            System.out.println("NOC: Ion know what you mean, faggot ass nigga. Try again.");
            return false;
        }

        if (commandWord == CommandWord.HELP) {
            printHelp();
        }
        else if (commandWord == CommandWord.GO) {
            goRoom(command);
        }
        else if (commandWord == CommandWord.QUIT) {
            wantToQuit = quit(command);
        }
        return wantToQuit;
    }
 
    private void printHelp(){
        System.out.println("Your phone's battery is dead.");
        System.out.println("You have no idea where you are.");
        System.out.println();
        System.out.println("However, your command words are:");
        parser.showCommands();
    }

    private void goRoom(Command command){
        if(!command.hasSecondWord()) {
            System.out.println("Go where?");
            return;
        }

        String direction = command.getSecondWord();

        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("There is no door there, cuh!");
        }
        else {
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription());
        }
    }
    
    
    private boolean quit(Command command){
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;
        }
    }
}
