/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zuulframework;

/**
 *
 * @author jonas
 */

public class start{
    public static void main(String[] args){
        //make an object of the game
        Game g = new Game();
        //start the game
        g.play();
    }
}
